part of 'cars_bloc.dart';

sealed class CarsState extends Equatable {
  const CarsState();

  @override
  List<Object> get props => [];
}

final class CarsInitial extends CarsState {}

final class CarsLoadInProgress extends CarsState {}

final class CarsLoadSuccess extends CarsState {
  final Car car;
  const CarsLoadSuccess({required this.car});

  @override
  List<Object> get props => [car];
}

final class CarsLoadFailure extends CarsState {
  final Object? exception;
  const CarsLoadFailure({this.exception});

  @override
  List<Object> get props => [exception!];
}
