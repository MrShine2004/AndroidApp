import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import 'package:cpsrpoproject/domain/repository/cars/cars_repository.dart';
import 'package:cpsrpoproject/domain/repository/model/car.dart';
import 'package:talker_flutter/talker_flutter.dart';

part 'cars_event.dart';
part 'cars_state.dart';

class CarsBloc extends Bloc<CarsEvent, CarsState> {
  final CarsRepository carsRepository;
  CarsBloc(this.carsRepository) : super(CarsInitial()) {
    on<CarsLoad>(_onCarsLoad);
  }

  Future<void> _onCarsLoad(CarsLoad event, Emitter<CarsState> emit) async {
    try {
      emit(CarsLoadInProgress());
      final car = await carsRepository.getCars(event.carId);
      emit(CarsLoadSuccess(car: car));
    } catch (error, stackTrace) {
      emit(CarsLoadFailure(exception: error));
      talker.handle(error, stackTrace);
    }
  }
}
