part of 'cars_bloc.dart';

sealed class CarsEvent extends Equatable {
  const CarsEvent();

  @override
  List<Object> get props => [];
}

class CarsLoad extends CarsEvent {
  final int carId;
  const CarsLoad({required this.carId});

  @override
  List<Object> get props => [carId];
}
